﻿namespace ASC_Web.Controllers
{
    public class AnonymousController : BaseController
    {
    }
}
