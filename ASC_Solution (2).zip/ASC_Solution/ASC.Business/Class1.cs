﻿namespace ASC.Business
{
    public class Class1
    {

    }
}
