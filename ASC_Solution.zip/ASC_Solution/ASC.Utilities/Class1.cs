﻿namespace ASC.Utilities
{
    public class Class1
    {

    }
}
