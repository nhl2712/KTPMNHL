﻿namespace ASC.Model
{
    public class Class1
    {

    }
}
